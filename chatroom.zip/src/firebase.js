export default {
    apiKey: "AIzaSyDRWmuxaott11ARPzHwrxz2Uv_1ItZsJYI",
    authDomain: "login-85cba.firebaseapp.com",
    databaseURL: "https://login-85cba.firebaseio.com",
    projectId: "login-85cba",
    storageBucket: "login-85cba.appspot.com",
    messagingSenderId: "918542533523",
    appId: "1:918542533523:web:af0e542c8703f481e2de66",
    measurementId: "G-3FZH8CX950"
}