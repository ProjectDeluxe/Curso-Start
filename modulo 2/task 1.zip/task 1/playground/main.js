// Javascript Basics (parte uno)
var startingJavascript = "Starting Javascript...";
console.log(startingJavascript);


var myName = "Agustin";
console.log(myName);


var age = 20
console.log(age);


var ignasiAge = 32
var ageDiff = ignasiAge - age  
console.log(ageDiff);


var older = "You are older than 21";
var notOlder = "You are not older than 21";
if (age < 21){
	console.log(notOlder);
} else {
	console.log(older);
}


var ignasiOlder = "Ignasi is older than you";
var ignasiYounger = "Ignasi is younger than you";
var ignasiSame = "You have the same age as Ignasi";
if (ignasiAge > age){
	console.log(ignasiOlder);
} else if(ignasiAge < age){
	console.log(ignasiYounger);
} else {
	console.log(ignasiSame);
}
// Javascript Array Functions (parte dos)
var compas = ["alan", "diego", "nahuel", "lean", "ariel", "erica", "teo", "ivan", "lucio", "nico", "meji", "gian", "rocio", "lucas", "roman", "lucas", "gaby", "nahuel", "mati", "edu", "eze", "elias", "nico", "jose", "rodri", "branko", "agus"]
compas.sort();
console.log(compas[0]);
console.log(compas[26]);

for(var i = 0; i < compas.length; i++)
	console.log(compas [i]);


var ages = [17, 17, 18, 18, 18, 18, 18, 18, 18, 32, 19, 19, 19, 19, 19, 20, 20, 8, 20, 20, 21, 21, 21, 23, 23, 24, 25, 26]
var z = 0
while(z < ages.length){
	console.log(ages[z]);
	z++
}


var z = 0
while(z < ages.length){
	if (ages[z] % 2 == 0){
		console.log(ages[z]);
	}
	z++
}


for(var i = 0; i < ages.length; i++){
	if (ages[i] % 2 == 0){
		console.log(ages [i]);
	}
}


var lowest = ages[0]
for(var i = 1; i < ages.length; i++){
	if(ages[i] < lowest){
		lowest = ages[i]
	}
}
console.log(lowest)


var biggest = ages[0]
for(var i = 1; i < ages.length; i++){
	if(ages[i] > biggest){
		biggest = ages[i]
	}
}
console.log(biggest)



console.log(Math.min.apply(null, ages))

console.log(Math.max.apply(null, ages))


function arrayPosition(array, index){
	console.log(array[index])
}
arrayPosition(ages, 9)


function repeatedNumbers(array){
	var repetidas=[]
	for(var i = 0; i < array.length; i++){
		for(var j = i + 1; j < array.length; j++){
			if(array[i] == array[j]){
				if(repetidas.indexOf(array[i]) == -1){
					repetidas.push(array[i])
				}
			}
		}
	}
	console.log(repetidas)
}
repeatedNumbers(ages)


var myColor = ['"Red"', '"Green"', '"White"', '"Black"'];
var x = myColor.toString();
console.log(x)


// Javascript String Functions (parte 3)


function reverseANumber(n){
	n = n.toString()
	return n.split().reverse().join();
}
console.log(reverseANumber(32443));


function alphabetOrder(str){
	return str.split('').sort().join('');
}
console.log(alphabetOrder("webmaster"));
console.log(alphabetOrder("vjmeasmacijwromaksckafweojn"));
console.log(alphabetOrder(",mc zlmv l vsfjancancksdnvka"));


function uppercase(str){
	var spl = str.split(' ');
	var array = [];
	for(var i = 0; i < spl.length; i++){
		array.push(spl[i].charAt(0).toUpperCase()+spl[i].slice(1));
	}
	return array.join(' ');
}
console.log(uppercase("prince of persia"));
console.log(uppercase("bokita papa"));
console.log(uppercase("hola como estas"));


function longestWord(str){
  var mtch = str.match(/\w[a-z]{0,}/gi);
  var result = mtch[0];
  for(var i = 0 ; i < mtch.length ; i++){ 
    if(result.length < mtch[i].length){
    result = mtch[i];
    } 
  }
  return result;
}
console.log(longestWord('Web Development Tutorial'));
