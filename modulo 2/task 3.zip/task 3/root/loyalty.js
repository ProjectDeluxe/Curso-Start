var members = data.results[0].members
const filter_members = members.filter(member => member.total_votes != 0)


let statistics ={
    n_democratas:32,

}
function total(x){
    return members.filter(e => e.party == x)
}




let stats = {
    "cantidadDemocrats" : 0,
	"cantidadRepublicans" : 0,
	"cantidadIndependents" : 0,
	'cantidadTotal' : 0,
	"porcentajePromedioD" : 0,
	"porcentajePromedioR" : 0,
	"porcentajePromedioI" : 0,
	"porcentajeTotal" : 0,
	"least_loyal" : [],
	"most_loyal" : [],
	"least_engaged" : [],
	"most_engaged" : [],
	"least_missed_votes" : [],
	"most_missed_votes" : []
}
stats.cantidadDemocrats = total("D").length
stats.cantidadRepublicans = total("R").length
stats.cantidadIndependents = total("I").length

for (let i = 0; i < members.length; i++){
    stats.cantidadTotal++;
    stats.porcentajeTotal += members[i].votes_with_party_pct;
}

stats.porcentajeTotal =+ (stats.porcentajeTotal / stats.cantidadTotal).toFixed(2);


let democratList = total("D");
let republicanList = total("R");
let independentList = total("I");


let tablaAmount = document.getElementById("amountTbody")


let porcentDemocrats = 0
let porcentRepublicans = 0
let porcentIndependents = 0

for(let i = 0; i < democratList.length; i++){
    porcentDemocrats += democratList[i].votes_with_party_pct
}
stats.porcentajePromedioD =+ (porcentDemocrats / stats.cantidadDemocrats).toFixed(2)


for(let i = 0; i < republicanList.length; i++){
    porcentRepublicans += republicanList[i].votes_with_party_pct
}
stats.porcentajePromedioR =+ (porcentRepublicans / stats.cantidadRepublicans).toFixed(2)


for(let i = 0; i < independentList.length; i++){
    porcentIndependents += independentList[i].votes_with_party_pct
}
stats.porcentajePromedioI =+ (porcentIndependents / stats.cantidadIndependents).toFixed(2)




for(let i = 0; i < 4; i++){
    if(i == 0 && !isNaN(stats.porcentajePromedioD)){
        tablaAmount.innerHTML += '<tr><td>Democrats</td><td>' + stats.cantidadDemocrats  + '</td><td>' + stats.porcentajePromedioD + '%</td></tr>'
    }
    else if(i == 0 ){
        tablaAmount.innerHTML += '<tr><td>Democrats</td><td>' + stats.cantidadDemocrats  + '</td><td>-</td></tr>'
    }


    if(i == 1 && !isNaN(stats.porcentajePromedioR)){
        tablaAmount.innerHTML += '<tr><td>Republicans</td><td>' + stats.cantidadRepublicans  + '</td><td>' + stats.porcentajePromedioR + '%</td></tr>'
    }
    else if(i == 1){
        tablaAmount.innerHTML += '<tr><td>Republicans</td><td>' + stats.cantidadRepublicans  + '</td><td>-</td></tr>'
    }


    if(i == 2 && !isNaN(stats.porcentajePromedioI)){
        tablaAmount.innerHTML += '<tr><td>Independents</td><td>' + stats.cantidadIndependents  + '</td><td>' + stats.porcentajePromedioI + '%</td></tr>'
    }
    else if(i == 2){
        tablaAmount.innerHTML += '<tr><td>Independents</td><td>' + stats.cantidadIndependents  + '</td><td>-</td></tr>'
    }


    if(i == 3){
        tablaAmount.innerHTML += '<tr><td>Total</td><td>' + stats.cantidadTotal  + '</td><td>' + stats.porcentajeTotal + '%</td></tr>'
    }
}

// least most loyal tables



calculate()
createTables('least_loyal', stats.least_loyal, "votes_with_party_pct")
createTables('most_loyal', stats.most_loyal, "votes_with_party_pct")

function calculate(){
    stats.most_loyal = tenPct(filter_members,"votes_with_party_pct",false)
    stats.least_loyal = tenPct(filter_members,"votes_with_party_pct",true)
}

function tenPct(array,key,isAscendent){
    let result
    let i
    let aux = isAscendent ? 
                [...array].sort((a,b) => a[key] - b[key]) 
            : 
                [...array].sort((a,b) => b[key] - a[key])
    
    let tenPct = parseInt(aux.length*0.1)

    result = aux.slice(0,tenPct)


    i = result.length

    while(aux[i][key] == result[result.length - 1][key] && i < aux.length){
        result.push(aux[i])
        i++
    }

    return result

}


function createTables(id,array,key){
    if(document.getElementById(id)){
        let thead = `<thead>
                        <tr>
                            <th>Full Name</th>
                            <th>${key.replace(/_/g, " ").replace(/pct/, "")}</th>
                            <th>${key.replace(/_/g, " ").replace(/pct/, "%")}</th>
                        </tr>
                    </thead>`
         let tbody = '<tbody>' +  array.map(e => {
                            return `<tr>
                                        <td>${e.last_name}</td>
                                        <td>${key == "missed_votes_pct" ? e.missed_votes : Math.round(e.votes_with_party_pct * e.total_votes / 100)}</td>
                                        <td>${e[key]}</td>
                                    </tr>`
                        }).join('') + '</tbody>'

         document.getElementById(id).innerHTML = thead + tbody
    }else{
        return 0
    }
    
}