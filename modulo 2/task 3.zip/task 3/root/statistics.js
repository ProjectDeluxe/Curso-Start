var members = data.results[0].members


let statistics ={
    n_democratas:32,

}
function total(x){
    return members.filter(e => e.party == x)
}
total("D").length
console.log(total("D").length)