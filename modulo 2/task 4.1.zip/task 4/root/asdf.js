

const app = new Vue({
    el: `#app`,
    data:{
        url: "https://api.propublica.org/congress/v1/113/house/members.json",
        init: {
            method: `GET`,
            headers:{
                "X-API-Key": "jkpwFiFwFLiipoOi8BmjIrFhBGZkUJd5R6dBBN5K"
            }
           
        },
        members:[],
    },
    created(){
            fetch(this.url, this.init)
            .then(function(res){
                if(res.ok){
                    return res.json()
                }else{
                    throw new Error(status)
                }
            }) 
            .then(function(json){
                app.members = json.results[0].members
            })
            .catch(function(error){
                console.log(error)
            })
        }
})
