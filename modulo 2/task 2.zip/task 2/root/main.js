var members = data.results[0].members
var tbody = document.querySelector("tbody")

// checkbox
var statesAll = ["all"]
for(let i = 0; i <members.length; i++ ){
	if(statesAll.indexOf(members[i].state) == -1)
		statesAll.push(members[i].state)
}
for(let i=0;i<statesAll.length;i++)
	document.getElementById("dropdown").innerHTML += `<option value=${statesAll[i]} > ${statesAll[i]} </option>`
function filter(){
	tbody.innerHTML = ""
	var checkBox = document.getElementsByClassName("check")
	var dropDown = document.getElementById("dropdown").value
	for(let i = 0; i < checkBox.length; i++){
		if(checkBox[i].checked){
			members.filter(el => el.party == checkBox[i].value && (el.state == dropDown || dropDown== "all")).forEach(e => {
				var row = tbody.insertRow(-1)
				var fullname = `${e.first_name} ${e.middle_name || ""} ${e.last_name}`
				e.url != "" ? fullname = `<a href="${e.url}">${fullname}</a>` : null
				row.innerHTML = 
				`<td>${fullname}</td>
				<td> ${e.party}</td>
				<td> ${e.state}</td>
				<td> ${e.seniority}</td>
				<td> ${e.votes_with_party_pct} % </td>`
			})
		}
	}
}
document.getElementById("dem").addEventListener("click",filter)
document.getElementById("rep").addEventListener("click",filter)
document.getElementById("ind").addEventListener("click",filter)
filter()



