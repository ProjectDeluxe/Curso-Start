

const app = new Vue({
    el: `#app`,
    data:{
        init: {
            method: `GET`,
            headers:{
                "X-API-Key": "jkpwFiFwFLiipoOi8BmjIrFhBGZkUJd5R6dBBN5K"
            }
           
        },
        members:[],
        filter_members:[],
        parties:["R","D","I"],
        states:[],
        selected:"All",
        atGlance: {
            no_dem: 0,
            no_rep: 0,
            no_inds: 0,
            total: 0,
            votes_dem: 0,
            votes_rep: 0,
            votes_inds: 0,
            total_votes: 0,
            least_engaged : [],
	        most_engaged : [],
        }
    },

    created(){
        let url
        document.getElementById("senate") ? url = "https://api.propublica.org/congress/v1/113/senate/members.json" : url = "https://api.propublica.org/congress/v1/113/house/members.json" 
            fetch(url, this.init)
            .then(function(res){
                if(res.ok){
                    return res.json()
                }else{
                    throw new Error(status)
                }
            }) 
            .then(function(json){
                app.members = json.results[0].members
                app.members.forEach(member => {
                    if(app.parties.indexOf(member.party) == -1){
                        app.parties.push(member.party)
                    }
                    if(app.states.indexOf(member.state) == -1){
                        app.states.push(member.state)
                    }        
                })
                app.calculate()
                app.filter_members = app.members.filter(member => member.total_votes != 0)
                app.engaged()
            })
            
            .catch(function(error){
                console.log(error)
            })
        },
        computed:{
            filterStates(){
                return this.members.filter(el => app.parties.includes(el.party) && (el.state == app.selected || app.selected == "All"))
            }
        },
        methods: {
            calculate(){
                this.members.forEach(e => {
                    switch(e.party){
                        case "D":
                            this.atGlance.no_dem ++
                            this.atGlance.votes_dem += e.votes_with_party_pct
                            break
                        case "R": 
                            this.atGlance.no_rep ++
                            this.atGlance.votes_rep += e.votes_with_party_pct
                            break
                        case "I": 
                            this.atGlance.no_inds ++
                            this.atGlance.votes_inds += e.votes_with_party_pct
                            break
                    }
                })
    
                this.atGlance.total = this.members.length
                var votesPct = 0
                this.atGlance.total_votes = this.members.forEach(member => {
                    votesPct += member.votes_with_party_pct 
                });
                this.atGlance.votes_dem = (this.atGlance.votes_dem / this.atGlance.no_dem).toFixed(2)
                this.atGlance.votes_rep = (this.atGlance.votes_rep / this.atGlance.no_rep).toFixed(2)
                this.atGlance.votes_inds = (this.atGlance.votes_inds / this.atGlance.no_inds).toFixed(2)
                this.atGlance.total_votes = (votesPct / this.members.length).toFixed(2) 
                
            },

            engaged(){
                this.atGlance.least_engaged = this.tenPct(this.filter_members,"missed_votes_pct",false)
                this.atGlance.most_engaged = this.tenPct(this.filter_members,"missed_votes_pct",true)
            },

            tenPct(array,key,isAscendent){
                let result
                let i
                let aux = isAscendent ? 
                            [...array].sort((a,b) => a[key] - b[key]) 
                        : 
                            [...array].sort((a,b) => b[key] - a[key])
                
                let tenPct = parseInt(aux.length*0.1)

                result = aux.slice(0,tenPct)


                i = result.length

                while(aux[i][key] == result[result.length - 1][key] && i < aux.length){
                    result.push(aux[i])
                    i++
                }

                return result

            }
            
        },
        components: {
            stats_table:{
                props: ["array","isAscendent", "field1", "field2"],
                methods: {
                  tenPct(array,key,isAscendent){
    
                    if(array.length === 0){
                      return
                    }
    
                    let result
                    let i
                    let aux = isAscendent ? 
                                [...array].sort((a,b) => a[key] - b[key]) 
                            : 
                                [...array].sort((a,b) => b[key] - a[key])
                    
                    let tenPct = parseInt(aux.length*0.1)
    
                    result = aux.slice(0,tenPct)
    
    
    
                    i = result.length
    
                    while(aux[i][key] == result[result.length - 1][key] && i < aux.length){
                        result.push(aux[i])
                        i++
                    }
    
                    return result
            }
                },
                template: `
                                <tbody>
                                    <tr v-for="member in tenPct(array,field2,isAscendent)">
                                        <td>{{member.last_name}}, {{member.first_name}} {{member.middle_name}}</td>
                                        <td>{{member[field1]}}</td>
                                        <td>{{member[field2]}}%</td>
    
                                    </tr>
                                </tbody>
                                `
            }
        }
})