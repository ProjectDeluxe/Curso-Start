

const app = new Vue({
    el: `#app`,
    data:{
        init: {
            method: `GET`,
            headers:{
                "X-API-Key": "jkpwFiFwFLiipoOi8BmjIrFhBGZkUJd5R6dBBN5K"
            }
           
        },
        members:[],
        parties:[],
        states:[],
        selected:"All"
    },
    created(){
        let url
        document.getElementById("senate") ? url = "https://api.propublica.org/congress/v1/113/senate/members.json" : url = "https://api.propublica.org/congress/v1/113/house/members.json" 
            fetch(url, this.init)
            .then(function(res){
                if(res.ok){
                    return res.json()
                }else{
                    throw new Error(status)
                }
            }) 
            .then(function(json){
                app.members = json.results[0].members
                app.members.forEach(member => {
                    if(app.parties.indexOf(member.party) == -1){
                        app.parties.push(member.party)
                    }
                    if(app.states.indexOf(member.state) == -1){
                        app.states.push(member.state)
                    }
                })
            })
            .catch(function(error){
                console.log(error)
            })
        },
        computed:{
            filterStates(){
                return this.members.filter(el => app.parties.includes(el.party) && (el.state == app.selected || app.selected == "All"))
            }
        }
})

